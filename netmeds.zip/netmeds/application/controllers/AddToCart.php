<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class AddToCart extends CI_Controller {
    
    //This Function is use for Add product in cart//
    public function index()
    {
        $this->load->model('AddToCartModel');
        $data=$this->AddToCartModel->index();
        if($this->cart->contents()){
            $i="";
            foreach($this->cart->contents() as $singleValue){
                $i++;
                if($singleValue['id'] == $data->id){

                    $message=array('msg'=>'This product is Already in your Cart..!','type'=>'warning');
                    $this->session->set_flashdata('data',$message);
                    redirect('products');
                }
            }
            if($i == count($this->cart->contents())){
                $this->insertproduct($data);
            }
        }else{
            $this->insertproduct($data);
        }
    }

    //Add product in cart
    public function insertproduct($data)
    {
        //Create Array for product store in session
        $product = array(
            'id'      => $data->id,
            'qty'     => 1,
            'price'   => $data->minPrice,
            'name'    => $data->itemName
        );
        if($this->cart->insert($product)){
            $message=array('msg'=>'Product Added in Cart..!','type'=>'success');
            $this->session->set_flashdata('data',$message);
            redirect('products');
        }
    }

    //Remove Product from cart
    public function RemoveItem()
    {
        if($this->cart->remove($this->input->post('rowid'))){
            $message=array('msg'=>'Product Remove Succesfully..!','type'=>'info');
            $this->session->set_flashdata('data',$message);
            redirect('cart');
        }else{
            $message=array('msg'=>'Something went wrong..!','type'=>'warning');
            $this->session->set_flashdata('data',$message);
            redirect('cart');
        }
    }

    //Session Check redirect to checkout view
    public function Checkout()
    {
        if(!$this->session->userdata('userid')){
            redirect('UserLogin');
        }else{
            $this->load->view('checkout');
        }
    }
}