<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Cart extends CI_Controller {

    //View Cart page
    public function index()
    {
        $this->load->view('cart');
    }

    //insert order data and order details
    public function bookNow()
    {
        $this->load->model('CartModel');

        $data=array(
            'user_id'=>$this->session->userdata('userid'),
            'patient_name'=>$this->input->post('name'),
            'email'=>$this->input->post('email'),
            'phone'=>$this->input->post('phone'),
            'slot'=>$this->input->post('slot'),
            'address'=>$this->input->post('address')
        );

        if($this->cart->total_items()){

            $order_id=$this->CartModel->orderDetails($data);
            $totalItem= array();
            foreach ($this->cart->contents() as $items){
                
                $cartItem=array(
                    'order_id'=>$order_id,
                    'product_name'=>$items['name'],
                    'price'=>$items['price']
                );
                array_push($totalItem,$cartItem);
            }
            
            if($this->CartModel->orderInfo($totalItem)){
                $this->cart->destroy();
                $data=$this->CartModel->ordersuccess($order_id);
                $this->load->view('order_complete',['data'=>$data]);
            }
        }

    }

}