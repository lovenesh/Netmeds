<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Products extends CI_Controller {

    //Fetch Products For view//
    public function index() {

        $this->load->model('ProductModel');
        $this->load->view('Products_view',['data'=>$this->ProductModel->products()]);
    }
}
