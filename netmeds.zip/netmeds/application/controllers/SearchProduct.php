<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class SearchProduct extends CI_Controller {
    
    //search product ajax 
    public function index()
    {
        if($this->input->post('keyword')){
            $this->load->model('SearchProductModel');
            $result=$this->SearchProductModel->index();
            echo "<ul id='product-list'>";
                foreach($result as $value){
                    echo "<li onClick='selectCountry('". $value->itemName."')'>";
                    echo "<img class='serch-img' src='https://www.netmeds.com/images/cms/wysiwyg/Diagnostics/2020/netmeds-immunity-care_without-discount.jpg'>";
                    echo "<span>".$value->itemName."</span>";
                    echo "<form method='post' action='".base_url()."AddToCart'>";
                    echo form_input(['type'=>'hidden','name'=>'productId','value'=>$value->id]);
                    echo "<button type='submit' style='float:right;'>
                            <img src='https://cdn.iconscout.com/icon/free/png-256/add-in-shopping-cart-461858.png' style='width:30px; height:30px;'></form>
                        </button>";
                    echo "<span class='product__price' style='color:#ef4281;'>₹".$value->minPrice."</span>";
                    echo "</li>";
                }
        }
    }
}