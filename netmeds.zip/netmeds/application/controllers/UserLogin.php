<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class UserLogin extends CI_Controller {

    //view login page
    public function index(){
        
        $this->load->view('login');
    }

    //User Login Request Function
    public function login(){

        if($this->input->post()){
            $this->load->model('UserLoginModel');
            if($this->UserLoginModel->login()){
                $this->session->set_userdata('userid',$this->UserLoginModel->login()->id);
                $message=array('msg'=>'Login Succesfully..!','type'=>'success');
                $this->session->set_flashdata('data',$message);
                redirect('cart');
            }else{
                $message=array('msg'=>'Incorect details...!','type'=>'error');
                $this->session->set_flashdata('data',$message);
                $this->load->view('login');
            }
        }
    }

    //Logout session
    public function logout()
    {
        $this->session->unset_userdata('userid');
        if(!$this->session->userdata('userid')){
            $message=array('msg'=>'Logout Succesfully..!','type'=>'success');
            $this->session->set_flashdata('data',$message);
            redirect('products');
        }
        
    }
}