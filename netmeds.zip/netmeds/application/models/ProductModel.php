<?php 

class ProductModel extends CI_Model
{
    //Fetch products From DB//
    public function products(){

        return$this->db->where('status','1')
            ->get('products')
            ->result();
    }
} 

?>