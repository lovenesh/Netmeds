<?php

class CartModel extends CI_Model{

    //insert user details for order
    public function orderDetails($data)
    {
        $this->db->insert('orders',$data);
        return$this->db->insert_id();
    }

    //insert products details for order
    public function orderInfo($data)
    {
        return$this->db->insert_batch('orders_details', $data);
    }

    //Fetch products for success page
    public function ordersuccess($order_id)
    {
        return$this->db->where('order_id',$order_id)
                        ->get('orders_details')
                        ->result();
    }
}
?>