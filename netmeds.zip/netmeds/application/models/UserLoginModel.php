<?php

class UserLoginModel extends CI_Model
{
    //User Login Request Model//
    public function login()
    {
        return$this->db->select('id')
                ->where(['userId'=>$this->input->post('userId'),'pass'=>md5($this->input->post('pass')),'status'=>'1'])
                ->get('users')
                ->row();
    }

} 

?>