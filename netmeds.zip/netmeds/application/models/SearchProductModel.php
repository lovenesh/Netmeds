<?php

class SearchProductModel extends CI_Model
{
    public function index()
    {
        //Search product for ajax bar
        return$this->db->select(['products.id','itemName','minPrice'])
                    ->where('highlightresult.type','keyword')
                    ->like('value',$this->input->post('keyword'))
                    ->join('products', 'products.id = highlightresult.product_id')
                    ->get('highlightresult')
                    ->result();
    }

}

?>