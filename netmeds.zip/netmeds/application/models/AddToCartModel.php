<?php

class AddToCartModel extends CI_Model
{
    //Fetch product for add cart
    public function index()
    {
        return$this->db->where(['id'=>$this->input->post('productId'),'status'=>'1'])
                        ->get('products')
                        ->row();
    }
}
?>