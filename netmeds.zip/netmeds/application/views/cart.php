<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<!-- CSS -->
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/bootstrap-reboot.min.css">
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/bootstrap-grid.min.css">
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/theme-default.css">
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/paymentfont.min.css">
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/ionicons.min.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/main.css">
    <script src="//code.jquery.com/jquery-1.9.1.min.js"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.0.1/css/toastr.css" rel="stylesheet"/>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.0.1/js/toastr.js"></script>

	<!-- Favicons -->
	<link rel="icon" type="image/png" href="<?php echo base_url(); ?>assets/icon/favicon-32x32.png" sizes="32x32">
	<link rel="apple-touch-icon" href="<?php echo base_url(); ?>assets/icon/favicon-32x32.png">

	<meta name="description" content="">
	<meta name="keywords" content="">
	<meta name="author" content="Dmitry Volkov">
	<title>BeHealthy – Coronavirus Medical Prevention, Online Pharmacy Template</title>

</head>

<body>
	<!-- app -->
	<div id="app">
		<!-- header -->
		<header class="header">
			<div class="container">
				<div class="row">
					<div class="col-12">
						<div class="header__content">
							<a v-scroll-to="'#home'" href="<?= base_url(); ?>products" class="header__logo">
								<img src="<?php echo base_url(); ?>assets/img/logo.svg" alt="">
							</a>

							<nav class="header__nav">
							</nav>

							<div class="header__wrap">
								<div class="header__phone">
									<a href="tel:88001234567">+91 9999900000</a>
									<span>The call is free</span>
								</div>

								<a style="width:60px;" href="<?= base_url(); ?>cart" class="header__cart">
									<p style="color: #f0e9e9;background: #434343;border-radius: 20%;margin: 7%;padding: 2%;"><?= $this->cart->total_items(); ?></p>
									<svg xmlns="http://www.w3.org/2000/svg" width="512" height="512" viewBox="0 0 512 512"><circle cx="176" cy="416" r="16" style="fill:none;stroke-linecap:round;stroke-linejoin:round;stroke-width:32px"></circle><circle cx="400" cy="416" r="16" style="fill:none;stroke-linecap:round;stroke-linejoin:round;stroke-width:32px"></circle><polyline points="48 80 112 80 160 352 416 352" style="fill:none;stroke-linecap:round;stroke-linejoin:round;stroke-width:32px"></polyline><path d="M160,288H409.44a8,8,0,0,0,7.85-6.43l28.8-144a8,8,0,0,0-7.85-9.57H128" style="fill:none;stroke-linecap:round;stroke-linejoin:round;stroke-width:32px"></path></svg>
								</a>

								<?php if($this->session->userdata('userid')){ ?>
								<a href="<?= base_url(); ?>UserLogin/logout">
                                    <img src="https://t3.ftcdn.net/jpg/01/52/71/12/240_F_152711253_7J1blWps9QskMf86UKGCCjXDP102eKqb.jpg" style="width:20px; height:20px;margin-left: 15px;">
                                    <span>Logout</span>
								</a>
								<?php } ?>
							</div>
						</div>
					</div>
				</div>
			</div>
		</header>
		<!-- end header -->
		<!-- section -->
		<section class="section" style="padding:20px;" id="cart">
			<div class="container">
				<div class="row">
					<!-- cart -->
						<div class="col-12">
							<div class="cart">
								<div class="table-responsive">
									<table class="cart__table">
										<thead>
											<tr>
												<th>Product</th>
												<th>Test Name</th>
                                                <th>Unit Price</th>
												<th>Remove</th>
											</tr>
										</thead>

										<tbody>
                                        <?php foreach ($this->cart->contents() as $items): ?>
											<tr>
                                                <form id="RemoveItem" method="post" action="<?= base_url(); ?>AddToCart/RemoveItem">
			                                    <?php echo form_input(['type'=>'hidden','name'=>'rowid','value'=>$items['rowid']]); ?>
												<td>
													<div class="cart__img"><img src="https://www.netmeds.com/images/cms/wysiwyg/Diagnostics/2020/netmeds-immunity-care_without-discount.jpg" alt=""></div>
												</td>
												<td><?= $items['name']; ?></td>
												<td><span class="cart__price">₹ <?= $items['price']; ?></span></td>
												<td><button class="cart__delete" type="submit">
                                                        <svg xmlns='http://www.w3.org/2000/svg' width='512' height='512' viewBox='0 0 512 512'>
                                                        <line x1='368' y1='368' x2='144' y2='144' style='fill:none;stroke-linecap:round;stroke-linejoin:round;stroke-width:32px'/>
                                                        <line x1='368' y1='144' x2='144' y2='368' style='fill:none;stroke-linecap:round;stroke-linejoin:round;stroke-width:32px'/>
                                                        </svg>
                                                    </button>
                                                </td>
                                                </form>
                                            </tr>
                                        <?php endforeach;
                                        if(!$this->cart->total_items()) {
                                        ?>
                                            <tr>
												<td colspan="6">
													<p class="cart__empty">
														Cart is empty
													</p>
												</td>
                                            </tr>
                                        <?php } ?>
										</tbody>
									</table>
								</div>

								<div class="cart__info">
									<div class="cart__total">
										<p>Total:</p>
										<span>₹ <?php print_r($this->cart->total()); ?></span>
                                    </div>
                                    <?php if($this->cart->total_items()) { ?> 
                                    <form id="Checkout" method="post" action="<?= base_url(); ?>AddToCart/Checkout">
                                        <div>
                                            <button class="form__btn" type="submit">Checkout</button>
                                        </div>
                                    </form>
                                    <?php } ?>
									<div class="cart__systems">
										<i class="pf pf-visa"></i>
										<i class="pf pf-mastercard"></i>
										<i class="pf pf-paypal"></i>
									</div>
								</div>
							</div>
						</div>
					<!-- end cart -->
				</div>
			</div>
		</section>
		<!-- end section -->	
		<!-- section -->
		<section class="section" id="about">
			<div class="container">
				<div class="row">
					<div class="col-12">
						<!-- section title -->
						<h2 class="section__title">About <b>BeHealthy</b></h2>
						<!-- end section title -->

						<!-- section text -->
						<p class="section__text">Netmeds – Coronavirus Medical Prevention, Online Pharmacy <b>Vue.js Template</b>. BeHealthy is a good choice for all medical facilities, <b>online pharmacy</b>, raise awareness of (2019-nCoV). Template is optimized and fully responsive, SEO optimised, based on Bootstrap 4.x, have clean code and speed fast.</p>
						<!-- end section text -->
					</div>
				</div>
			</div>
		</section>
		<!-- end section -->

		<!-- footer -->
		<footer class="footer">
			<div class="container">
				<div class="row">
					<div class="col-12">
						<div class="footer__content">
							<h6 class="footer__copyright">© 2020 Netmeds <span>Create by <a href="https://themeforest.net/user/dmitryvolkov/portfolio" target="_blank">Dmitry Volkov</a></span></h6>

							<div class="footer__social">
								<a class="facebook" href="#"><i class="ion ion-logo-facebook"></i></a>
								<a class="instagram" href="#"><i class="ion ion-logo-instagram"></i></a>
								<a class="twitter" href="#"><i class="ion ion-logo-twitter"></i></a>
								<a class="vk" href="#"><i class="ion ion-logo-vk"></i></a>
							</div>
						</div>
					</div>
				</div>
            </div>
            <?php echo $this->session->flashdata('data')['msg'];?>
		</footer>
		<!-- end footer -->
	</div>
    <!-- end app -->
    <!--Use For Toser Msg-->
    <script type="text/javascript">
    $(document).ready(function() {
    
    <?php if($this->session->flashdata('data')){ ?>
        toastr.<?= $this->session->flashdata('data')['type'];?>('<?= $this->session->flashdata('data')['msg']; ?>');
    <?php }?>
    
    $('#linkButton').click(function() {
       toastr.success('Click Button');
    });
  });
  </script>
	<!-- JS -->
	<script src="<?php echo base_url(); ?>assets/js/vue.js"></script>
	<script src="<?php echo base_url(); ?>assets/js/vue-scrollto.js"></script>
	<script src="<?php echo base_url(); ?>assets/js/vue-toast-notification.js"></script>
	<script src="<?php echo base_url(); ?>assets/js/products.js"></script>
	<!-- <script src="<?php echo base_url(); ?>assets/js/main.js"></script> -->
</body>
</html>