<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<!-- CSS -->
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/bootstrap-reboot.min.css">
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/bootstrap-grid.min.css">
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/theme-default.css">
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/paymentfont.min.css">
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/ionicons.min.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/main.css">
    <script src="//code.jquery.com/jquery-1.9.1.min.js"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.0.1/css/toastr.css" rel="stylesheet"/>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.0.1/js/toastr.js"></script>

	<!-- Favicons -->
	<link rel="icon" type="image/png" href="<?php echo base_url(); ?>assets/icon/favicon-32x32.png" sizes="32x32">
	<link rel="apple-touch-icon" href="<?php echo base_url(); ?>assets/icon/favicon-32x32.png">

	<meta name="description" content="">
	<meta name="keywords" content="">
	<meta name="author" content="Dmitry Volkov">
	<title>Ntemeds – Coronavirus Medical Prevention</title>

</head>

<body>
	<!-- app -->
	<div id="app">
		<!-- header -->
		<header class="header">
			<div class="container">
				<div class="row">
					<div class="col-12">
						<div class="header__content">
							<a v-scroll-to="'#home'" href="<?= base_url(); ?>products" class="header__logo">
								<img src="<?php echo base_url(); ?>assets/img/logo.svg" alt="">
							</a>
							<nav class="header__nav">
							</nav>

							<div class="header__wrap">
								<a style="width:60px;" href="<?= base_url(); ?>cart" class="header__cart">
									<p style="color: #f0e9e9;background: #434343;border-radius: 20%;margin: 7%;padding: 2%;"><?= $this->cart->total_items(); ?></p>
									<svg xmlns="http://www.w3.org/2000/svg" width="512" height="512" viewBox="0 0 512 512"><circle cx="176" cy="416" r="16" style="fill:none;stroke-linecap:round;stroke-linejoin:round;stroke-width:32px"></circle><circle cx="400" cy="416" r="16" style="fill:none;stroke-linecap:round;stroke-linejoin:round;stroke-width:32px"></circle><polyline points="48 80 112 80 160 352 416 352" style="fill:none;stroke-linecap:round;stroke-linejoin:round;stroke-width:32px"></polyline><path d="M160,288H409.44a8,8,0,0,0,7.85-6.43l28.8-144a8,8,0,0,0-7.85-9.57H128" style="fill:none;stroke-linecap:round;stroke-linejoin:round;stroke-width:32px"></path></svg>
                                </a>
                                <?php if($this->session->userdata('userid')){ ?>
								<a href="<?= base_url(); ?>UserLogin/logout">
                                    <img src="https://t3.ftcdn.net/jpg/01/52/71/12/240_F_152711253_7J1blWps9QskMf86UKGCCjXDP102eKqb.jpg" style="width:20px; height:20px;margin-left: 15px;">
                                    <span>Logout</span>
								</a>
								<?php } ?>
                            </div>
                            
						</div>
					</div>
				</div>
			</div>
		</header>
		<!-- end header -->

		<!-- section -->
		<section class="section">
			<div class="container">
				<div class="row">
					<div class="col-12">
						<!-- section title -->
						<h2 class="section__title">Checkout</h2>
						<!-- end section title -->
					</div>

					<!-- checkout -->
					<div class="col-12 col-lg-8">
                        <?php echo form_open('cart/bookNow', ['class'=>'checkout','id'=>'BookNow']); ?>
							<div class="row">
								<div class="col-12 col-md-6">
									<div class="form__group">
										<input type="text" name="name" placeholder="Patient Name">
									</div>
								</div>

								<div class="col-12 col-md-6">
									<div class="form__group">
										<input type="email" name="email" placeholder="Email Address">
									</div>
								</div>

								<div class="col-12 col-md-6">
									<div class="form__group">
										<input type="text" name="phone" placeholder="Phone No.">
									</div>
								</div>

								<div class="col-12 col-md-6">
									<div class="form__group form__group--select">
										<select name="slot">
											<option value="" disabled selected>Time Slot</option>
											<option value="5:00pm - 6:00pm">5:00pm - 6:00pm</option>
											<option value="6:00pm - 7:00pm">6:00pm - 7:00pm</option>
											<option value="7:00pm - 8:00pm">7:00pm - 8:00pm</option>
										</select>
									</div>
								</div>

								<div class="col-12">
									<div class="form__group">
										<textarea name="address" placeholder="Pickup address"></textarea>
									</div>
								</div>

								<div class="col-12">
									<button class="form__btn" type="submit">Book Now</button>
								</div>
							</div>
						</form>
					</div>
					<!-- end checkout -->

					<!-- contacts -->
					<div class="col-12 col-lg-4">
						<div class="contacts">
							<h3 class="contacts__title">Free Shipping</h3>
							<p class="contacts__text">Free delivery in Moscow and <br>the Moscow region</p>
						</div>

						<div class="contacts">
							<h3 class="contacts__title"><a href="mailto:behealthy@supp.com">Supp@BeHealthy.com</a></h3>
							<p class="contacts__text">Our contact E-mail</p>
						</div>

						<div class="contacts">
							<h3 class="contacts__title contacts__title--phone"><a href="tel:88001234567">8 800 123 45 67</a></h3>
							<p class="contacts__text">Free calls in Moscow and <br>the Moscow region</p>
						</div>
					</div>
					<!-- end contacts -->
				</div>
			</div>
		</section>
		<!-- end section -->	

		<!-- section -->
		<section class="section" id="about">
			<div class="container">
				<div class="row">
					<div class="col-12">
						<!-- section title -->
						<h2 class="section__title">About <b>BeHealthy</b></h2>
						<!-- end section title -->

						<!-- section text -->
						<p class="section__text">BeHealthy – Coronavirus Medical Prevention, Online Pharmacy <b>Vue.js Template</b>. BeHealthy is a good choice for all medical facilities, <b>online pharmacy</b>, raise awareness of (2019-nCoV). Template is optimized and fully responsive, SEO optimised, based on Bootstrap 4.x, have clean code and speed fast.</p>
						<!-- end section text -->
					</div>
				</div>
			</div>
		</section>
		<!-- end section -->

		<!-- footer -->
		<footer class="footer">
			<div class="container">
				<div class="row">
					<div class="col-12">
						<div class="footer__content">
							<h6 class="footer__copyright">© 2020 BeHealthy <span>Create by <a href="https://themeforest.net/user/dmitryvolkov/portfolio" target="_blank">Dmitry Volkov</a></span></h6>

							<div class="footer__social">
								<a class="facebook" href="#"><i class="ion ion-logo-facebook"></i></a>
								<a class="instagram" href="#"><i class="ion ion-logo-instagram"></i></a>
								<a class="twitter" href="#"><i class="ion ion-logo-twitter"></i></a>
								<a class="vk" href="#"><i class="ion ion-logo-vk"></i></a>
							</div>
						</div>
					</div>
				</div>
            </div>
            <?php echo $this->session->flashdata('data')['msg'];?>
		</footer>
		<!-- end footer -->
	</div>
    <!-- end app -->
    <!--Use For Toser Msg-->
    <script type="text/javascript">
    $(document).ready(function() {
    
    <?php if($this->session->flashdata('data')){ ?>
        toastr.<?= $this->session->flashdata('data')['type'];?>('<?= $this->session->flashdata('data')['msg']; ?>');
    <?php }?>
    
    $('#linkButton').click(function() {
       toastr.success('Click Button');
    });

    $('#BookNow').validate({
        rules: {
            "name": {
                required: true,
            },
            "email": {
                required: true,
            },
            "phone": {
                required: true,
            },
            "slot": {
                required: true,
            },
            "address": {
                required: true,
            }
        },
        messages: {
            "name": {
                required: 'This fied is required',
            },
            "email": {
                required: 'This fied is required',
            },
            "phone": {
                required: 'This fied is required',
            },
            "slot": {
                required: 'This fied is required',
            },
            "address": {
                required: 'This fied is required',
            }

        }
    });
  });
  </script>
    <!-- JS -->
    <!-- Form validation CDN -->
    <script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.2/dist/jquery.validate.js"></script>
	<script src="<?php echo base_url(); ?>assets/js/vue.js"></script>
	<script src="<?php echo base_url(); ?>assets/js/vue-scrollto.js"></script>
	<script src="<?php echo base_url(); ?>assets/js/vue-toast-notification.js"></script>
	<script src="<?php echo base_url(); ?>assets/js/products.js"></script>
	<!-- <script src="<?php echo base_url(); ?>assets/js/main.js"></script> -->
</body>
</html>