<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<!-- CSS -->
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/bootstrap-reboot.min.css">
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/bootstrap-grid.min.css">
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/theme-default.css">
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/paymentfont.min.css">
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/ionicons.min.css">
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/main.css">
	<!-- tostr notifications -->
    <script src="//code.jquery.com/jquery-1.9.1.min.js"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.0.1/css/toastr.css" rel="stylesheet"/>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.0.1/js/toastr.js"></script>
	<!-- Search Test/Package -->
	<script src="https://code.jquery.com/jquery-2.1.1.min.js" type="text/javascript"></script>

	<!-- Favicons -->
	<link rel="icon" type="image/png" href="<?php echo base_url(); ?>assets/icon/favicon-32x32.png" sizes="32x32">
	<link rel="apple-touch-icon" href="<?php echo base_url(); ?>assets/icon/favicon-32x32.png">

	<meta name="description" content="">
	<meta name="keywords" content="">
	<meta name="author" content="Dmitry Volkov">
	<title>NetMeds – Online Pharmacy</title>

	<!-- Search Test/package -->
	<script>
		$(document).ready(function(){
		$("#search-box").keyup(function(){
			$.ajax({
			type: "POST",
			url: "SearchProduct",
			data:'keyword='+$(this).val(),
			beforeSend: function(){
			$("#search-box").css("background","#FFF url(LoaderIcon.gif) no-repeat 165px");
			},
			success: function(data){
			$("#suggesstion-box").show();
			$("#suggesstion-box").html(data);
			$("#search-box").css("background","#FFF");
			}
			});
		});
		});

		function selectCountry(val) {
			$("#search-box").val(val);
			$("#suggesstion-box").hide();
		}
	</script>
<style>

#product-list{float:left;list-style:none;margin-top:-3px;padding:0;width: 100%; max-height:250px; overflow-y:auto;}
#product-list li{padding: 14px; background: #ffffff;; /*border-bottom: #bbb9b9 1px solid;*/}
#product-list li:hover{background:#f8f8f8;cursor: pointer;}
#search-box{padding: 10px;border: #dae8f6 1px solid;border-radius:4px;}
.serch-img {
  display: inline-block !important;
    margin-right: 8px !important;
    height: 37px !important;
    vertical-align: middle !important;
    width: 32px !important;
    padding-bottom: 12px !important;
}
* {box-sizing: border-box;}

.serch_top {
  overflow: hidden;
  float: left;
  width: 98%;
      margin: 2px;
  margin-top: 1%;
}


.serch_top s {
  float: left;
  display: block;
  color: black;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.serch_top a:hover {
  background-color: #ddd;
  color: black;
}

.serch_top a.active {
  background-color: #2196F3;
  color: white;
}

.serch_top input[type=text] {

  padding: 0 16px;
  margin-top: 8px;
  margin-right: 16px;
  border: none;
      height: 36px;
  font-size: 17px;
  background-color: #f1f1f1;
}
</style>
</head>
<body>
	<!-- app -->
	<div id="app">
		<!-- header -->
		<header class="header">
			<div class="container">
				<div class="row">
					<div class="col-12">
						<div class="header__content">
							<a v-scroll-to="'#home'" href="<?= base_url(); ?>products" class="header__logo">
								<img src="<?php echo base_url(); ?>assets/img/logo.svg" alt="">
							</a>

							<nav class="header__nav">
							</nav>

							<div class="header__wrap">
								<div class="header__phone">
									<a href="tel:88001234567">+91 9999900000</a>
									<span>The call is free</span>
								</div>

								<a style="width:60px;" href="<?= base_url(); ?>cart" class="header__cart">
									<p style="color: #f0e9e9;background: #434343;border-radius: 20%;margin: 7%;padding: 2%;"><?= $this->cart->total_items(); ?></p>
									<svg xmlns="http://www.w3.org/2000/svg" width="512" height="512" viewBox="0 0 512 512"><circle cx="176" cy="416" r="16" style="fill:none;stroke-linecap:round;stroke-linejoin:round;stroke-width:32px"></circle><circle cx="400" cy="416" r="16" style="fill:none;stroke-linecap:round;stroke-linejoin:round;stroke-width:32px"></circle><polyline points="48 80 112 80 160 352 416 352" style="fill:none;stroke-linecap:round;stroke-linejoin:round;stroke-width:32px"></polyline><path d="M160,288H409.44a8,8,0,0,0,7.85-6.43l28.8-144a8,8,0,0,0-7.85-9.57H128" style="fill:none;stroke-linecap:round;stroke-linejoin:round;stroke-width:32px"></path></svg>
								</a>
								<?php if($this->session->userdata('userid')){ ?>
								<a href="<?= base_url(); ?>UserLogin/logout">
                                    <img src="https://t3.ftcdn.net/jpg/01/52/71/12/240_F_152711253_7J1blWps9QskMf86UKGCCjXDP102eKqb.jpg" style="width:20px; height:20px;margin-left: 15px;">
                                    <span>Logout</span>
								</a>
								<?php } ?>
							</div>
						</div>
					</div>
				</div>
			</div>
		</header>
		<!-- end header -->

		<!-- home -->
		<section class="section section--home" id="home">
			<div class="container">
				<div class="row">
					<div class="col-12">
						<div class="home">
							<div class="row">
								<div class="col-12 col-sm-11 col-md-8 col-lg-6 col-xl-5">
									<div class="home__content">
										<h1 class="home__title">Coronavirus<br> Medical Prevention</h1>
										<p class="home__text">NetMeds is a good choice for all medical facilities, online pharmacy, raise awareness of (2019-nCoV).</p>
										<a v-scroll-to="'#catalog'" href="#" class="home__btn">PROTECT MYSELF</a>
									</div>
								</div>
							</div>		
						</div>
					</div>
				</div>
			</div>
		</section>
		<!-- end home -->

		<!-- section -->
		<section class="section" style="padding:20px;" id="cart">
			<div class="container">
				<div class="row">
					<!-- cart -->
						<div class="col-12">
							<div class="cart" style="padding:20px;">
								<div class="form__group">
									<input type="text" id="search-box" name="name" placeholder="Search For tests/packages">
									<div id="suggesstion-box"></div>
								</div>
							</div>
						</div>
					<!-- end cart -->
				</div>
			</div>
		</section>
		<!-- end section -->

		<!-- section -->
		<section class="section" id="catalog">
			<div class="container">
				<div class="row">
					<div class="col-12">
						<!-- section title -->
						<h2 class="section__title">Catalog</h2>
						<!-- end section title -->
					</div>
				</div>

				<!-- grid -->
				<transition-group class="row row--grid" tag="div">
					<?php foreach($data as $value)	
					{ ?>
						<div class="col-12 col-sm-6 col-lg-4">
						<form method="post" action="<?= base_url(); ?>AddToCart">
						<?php echo form_input(['type'=>'hidden','name'=>'productId','value'=>$value->id]); ?>
							<div class="product">
								<div class="product__img">
									<img src="https://www.netmeds.com/images/cms/wysiwyg/Diagnostics/2020/netmeds-immunity-care_without-discount.jpg" alt="">
								</div>
								<h3 class="product__title"><?= $value->itemName; ?></h3>
								<p class="contacts__text">Test Id : <?= $value->itemId; ?></p>
								<p class="contacts__text">Test category : <?= $value->category; ?></p>
								<p class="contacts__text">Total tests : <?= $value->testCount; ?></p>
								<p class="contacts__text">Lab Name : <?= $value->labName; ?></p>
								<p class="contacts__text">Fasting : <?php if($value->fasting){ echo 'Yes';}else{echo 'No';}; ?></p>
								<br>
								<span class="product__price" style="color:#ef4281;">₹<?= $value->minPrice; ?></span>
								<button class="product__add" type="submit">
									<svg xmlns='http://www.w3.org/2000/svg' width='512' height='512' viewBox='0 0 512 512'>
										<path d='M448,256c0-106-86-192-192-192S64,150,64,256s86,192,192,192S448,362,448,256Z' style='fill:none;stroke-miterlimit:10;stroke-width:32px'/>
											<line x1='256' y1='176' x2='256' y2='336' style='fill:none;stroke-linecap:round;stroke-linejoin:round;stroke-width:32px'/>
											<line x1='336' y1='256' x2='176' y2='256' style='fill:none;stroke-linecap:round;stroke-linejoin:round;stroke-width:32px'/>
									</svg>
								</button>
							</div>
						</form>
						</div>
					<?php 
					}
					?>
				</transition-group>
				<!-- grid -->
			</div>
		</section>
		<!-- end section -->	
		<!-- section -->
		<section class="section" id="about">
			<div class="container">
				<div class="row">
					<div class="col-12">
						<!-- section title -->
						<h2 class="section__title">About <b>BeHealthy</b></h2>
						<!-- end section title -->

						<!-- section text -->
						<p class="section__text">BeHealthy – Coronavirus Medical Prevention, Online Pharmacy <b>Vue.js Template</b>. BeHealthy is a good choice for all medical facilities, <b>online pharmacy</b>, raise awareness of (2019-nCoV). Template is optimized and fully responsive, SEO optimised, based on Bootstrap 4.x, have clean code and speed fast.</p>
						<!-- end section text -->
					</div>
				</div>
			</div>
		</section>
		<!-- end section -->

		<!-- footer -->
		<footer class="footer">
			<div class="container">
				<div class="row">
					<div class="col-12">
						<div class="footer__content">
							<h6 class="footer__copyright">© 2020 BeHealthy <span>Create by lovenesh Agrawal For Netmeds</span></h6>

							<div class="footer__social">
								<a class="facebook" href="#"><i class="ion ion-logo-facebook"></i></a>
								<a class="instagram" href="#"><i class="ion ion-logo-instagram"></i></a>
								<a class="twitter" href="#"><i class="ion ion-logo-twitter"></i></a>
								<a class="vk" href="#"><i class="ion ion-logo-vk"></i></a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</footer>
		<!-- end footer -->
	</div>
	<!-- end app -->
    <!--Use For Toser Msg-->
    <script type="text/javascript">
    $(document).ready(function() {
    
    <?php if($this->session->flashdata('data')){ ?>
        toastr.<?= $this->session->flashdata('data')['type'];?>('<?= $this->session->flashdata('data')['msg']; ?>');
    <?php }?>
    
    $('#linkButton').click(function() {
       toastr.success('Click Button');
    });
  });
  </script>

	<!-- JS -->
	<script src="<?php echo base_url(); ?>assets/js/vue.js"></script>
	<script src="<?php echo base_url(); ?>assets/js/vue-scrollto.js"></script>
	<script src="<?php echo base_url(); ?>assets/js/vue-toast-notification.js"></script>
	<script src="<?php echo base_url(); ?>assets/js/products.js"></script>
	<!-- <script src="<?php echo base_url(); ?>assets/js/main.js"></script> -->
</body>
</html>